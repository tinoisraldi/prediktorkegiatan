# spada_dikti_covid
prediksi keamanan jumlah peserta sebuah acara
